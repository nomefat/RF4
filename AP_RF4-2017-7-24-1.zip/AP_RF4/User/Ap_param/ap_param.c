#include "stm32f4xx_hal.h"
#include "ap_param.h"











struct_ap_param ap_param;

















