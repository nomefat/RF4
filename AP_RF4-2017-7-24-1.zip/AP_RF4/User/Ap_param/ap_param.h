#ifndef _AP_PARAM_H_
#define _AP_PARAM_H_


#include "stm32f4xx_hal.h"







typedef struct _ap_param{

	uint16_t ap_id;                                                           //     N1ֻ��
	uint16_t ap_version;                                                      //     N1ֻ��
	uint8_t ap_channel;
	uint32_t gprs_server_ip;
	uint16_t gprs_server_port;
	uint8_t ap_syn_param[6];
	uint16_t rp_version;                //eeprom ��rp�̼��汾��                       N1ֻ��
	uint16_t sensor_version;						   //eeprom ��sensor�̼��汾��                N1ֻ��

}struct_ap_param;








typedef struct _dev_list{

	uint16_t bind_id;
	uint16_t ap_channel;
	



}struct_dev_list;







extern struct_ap_param ap_param;






#endif


