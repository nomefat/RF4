#ifndef _DEBUG_UART_
#define _DEBUG_UART_





void debug_uart_send_string(char *pstr);



extern char debug_send_buff[];










#endif


