#include "stm32f4xx_hal.h"
#include "snp.h"
#include "typedef_struct.h"
#include "ap_param.h"
#include "rf_hal.h"
#include "string.h"


SNP_SYNC_PACKET_t syn_packet;
SNP_AP_ACK_PACKET_t ack_packet;


struct_systerm_info systerm_info;



extern uint8_t gprs_sec_flag ;
extern uint8_t rf_sec_flag ;


extern uint8_t rf_rx_buff[4][256];


extern void rf_write_buff(SPI_HandleTypeDef* hspi,void *ptr,int len);


extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi3;
extern SPI_HandleTypeDef hspi4;
extern SPI_HandleTypeDef hspi5;







int test;






void rf_send_syn_packet(void)
{
  memcpy( (uint8_t *)&syn_packet.sensor_param[1], (uint8_t *)ap_param.ap_syn_param, 6 );
	syn_packet.sPhr.ucSize = sizeof( SNP_SYNC_PACKET_t);
	syn_packet.sPhr.uiFcf = 0x0080;
	syn_packet.sPhr.ucSerNr++;
	syn_packet.sPhr.ucType = SNP_PACKET_TYPE_WORK;
	syn_packet.sPhr.uiDevId = 0;
	
	syn_packet.ucCurSecNr++;
	
	HAL_GPIO_WritePin(general_led_1_GPIO_Port,general_led_1_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(general_led_2_GPIO_Port,general_led_2_Pin,GPIO_PIN_RESET);	
	HAL_GPIO_WritePin(general_led_3_GPIO_Port,general_led_3_Pin,GPIO_PIN_RESET);	
	HAL_GPIO_WritePin(general_led_4_GPIO_Port,general_led_4_Pin,GPIO_PIN_RESET);
	
	rf_write_buff(RF1, (uint8_t *)&syn_packet ,syn_packet.sPhr.ucSize);
	rf_write_buff(RF2, (uint8_t *)&syn_packet ,syn_packet.sPhr.ucSize);	
	rf_write_buff(RF3, (uint8_t *)&syn_packet ,syn_packet.sPhr.ucSize);	
	rf_write_buff(RF4, (uint8_t *)&syn_packet ,syn_packet.sPhr.ucSize);	
	

	
	rf_io_tx_4();

//	HAL_GPIO_WritePin(general_led_1_GPIO_Port,general_led_1_Pin,GPIO_PIN_SET);	
}


void rf_send_updata_packet()
{
	test = 2;	
}

void rf_send_ack_packet()
{
	test = 3;
}


void HAL_SYSTICK_Callback(void)
{

	systerm_info.slot++;


	if((systerm_info.slot%512) == 0) //gprsʹ�����־
	{
		gprs_sec_flag += 1;
		rf_sec_flag +=1;
	}
	if((systerm_info.slot%64) == 0)  //����ͬ����
		rf_send_syn_packet();

	if((systerm_info.slot%64) == 1)  //����������
		rf_send_updata_packet();	

	if((systerm_info.slot%64) == 2)  //����ack��
		rf_send_ack_packet();
	
	
	
	
}












void rf_rx_data_handle(int index)
{
	
}












































