#ifndef GPRS_HAL_H_
#define GPRS_HAL_H_





void grps_power_off();

void grps_power_on();












#endif

